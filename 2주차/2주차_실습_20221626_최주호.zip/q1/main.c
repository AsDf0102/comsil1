#include "animal.h"
#include <stdio.h>

int main(void) {
	dog();
	blackcow();
	turtle();
}
