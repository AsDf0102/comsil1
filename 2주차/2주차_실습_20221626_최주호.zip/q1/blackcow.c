#include <stdio.h>
#include "animal.h"

void blackcow() {
	printf("blackcow\n");
}
