#include <stdio.h>
#include "animal.h"

void turtle() {
	printf("turtle\n");
}
