#include <stdio.h>
#include <string.h>
#include "book.h"

int main(void) {
	int T, N, length; // T는 테스트 케이스, N은 마지막 페이지 수, length는 문자열의 길이
	int count[10] = {0,}; // 페이지를 이루는 숫자들이 저장될 배열
	char str[11] = {0,}; // 문자열로 변환된 책 페이지가 저장될 배열

	scanf("%d", &T); // 테스트 케이스 입력
	
	for (int i=0; i<T; i++) { // T만큼 반복
		for (int c=0; c<10; c++) count[c] = 0; // 테스트 케이스가 반복될 때마다 count 배열 초기화
		scanf("%d", &N); // 마지막 페이지 수 입력
		for (int j=1; j<N+1; j++) { // 1~N까지의 페이지에서 반복
			turn(str, j); // 페이지(정수) >> 문자열로 저장
			length = strlen(str); // 문자열의 길이를 length에 저장
			num_check(str, count, length); // 각 페이지에 속해있는 숫자를 세고 그 횟수를 count 배열에 저장
		}
		result(count); // 총 결괏값을 출력, ex : 0 1 1 1 1 1 1 1 1
		printf("\n"); // 테스트 케이스가 끝날 때마다 줄 간격 한 칸 
	}
	
}
