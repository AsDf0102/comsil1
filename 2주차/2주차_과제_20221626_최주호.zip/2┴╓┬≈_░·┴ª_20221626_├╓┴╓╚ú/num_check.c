#include <stdio.h>

void num_check(char *str, int *count, int length) {
	for (int num=0; num<10; num++) {	// 0~9 까지의 숫자에서 반복(페이지에 각 숫자가 속해있나 확인하기 위함)
		for (int k=0; k<length; k++) {	// k는 인덱스의 역할 : 전체 문자열에서 각각의 요소값을 확인 
			if (str[k]==(num+'0')) { // 문자열의 요소 값이 num과 일치할 때
				count[num]++;	// 숫자를 세는 count 배열에서 num 인덱스를 갖는 요소의 값을 1 증가시킴
			}
		}		
	}
}
