#include <stdio.h>

void turn(char *str, int i) {
	sprintf(str, "%d", i); // sprintf 함수를 이용하여 정수에 해당하는 페이지 수를 문자열로 바꾼다
}
