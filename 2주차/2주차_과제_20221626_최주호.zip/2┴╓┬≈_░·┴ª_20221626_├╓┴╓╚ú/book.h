#include <stdio.h>

void turn(char *str, int i); // 정수를 문자열로 변환하는 함수

void num_check(char *str, int  *count, int length); // 페이지에 있는 숫자를 카운트하는 함수(ex: 페이지가 10일 때 0, 1에 +1)

void result(int *count); // 결과를 출력하는 함수(ex : 0 1 1 1 1 1 1 1 1)

 
