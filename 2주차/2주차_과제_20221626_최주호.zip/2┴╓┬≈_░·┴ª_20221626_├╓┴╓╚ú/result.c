#include <stdio.h>

void result(int *count) {
	for (int i=0; i<10; i++) {	// count(페이지의 숫자를 저장하는 배열)의 전체 요소 값을 출력하기 위해 반복문 시행
		printf("%d ", count[i]); // count의 각 요소를 출력, ex : 0 1 1 1 1 1 1 1 1
	}
}

