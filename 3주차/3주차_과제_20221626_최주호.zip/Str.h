class Str { // Str이라는 class 생성 
	private: // 접근 제어 지시자 private : 클래스 내부에 정의된 함수에서만 접근 허용(정보를 감출 때 사용됨)
		// 멤버변수
		char *str; // string의 내용
		int len; // string의 길이
	public: // 접근 제어 지시자 public : 외부에서도 접근 가능
		// 멤버함수
		Str(int leng); // leng은 string의 길이
		Str(const char *neyong); // neyong은 초기화할 내용이 들어감
		~Str(); //소멸자
		int length(void); // string의 길이를 리턴하는 함수;
		char *contents(void); // string의 내용을 리턴하는 함수
		int compare(class Str& a); // a의 내용과 strcmp
		int compare(const char *a); // a의 내용과 strcmp
		void operator=(const char *a); //string의 값을 대입
		void operator=(class Str& a); // Str의 내용을 대입
};
