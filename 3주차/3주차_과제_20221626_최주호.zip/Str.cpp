#include "Str.h"
#include <string.h>
#include <iostream>
using namespace std;

Str::Str(int leng) { // 생성자 : leng은 string의 길이
	if (leng<0) { // leng이 음수일 때
		cout << "error!" << endl; // 에러 메세지 출력
	}
	else { // leng이 음수가 아닐 때(0 혹은 양수)
		len = leng; // len에 leng(string의 길이) 저장
		str = new char[len+1]; // str에 크기가 (len+1)인 char 타입 배열을 동적 할당
	}
}

Str::Str(const char *neyong) { // 생성자 : neyong은 초기화할 내용이 들어감
	len = strlen(neyong); // len에 string의 길이 저장
	str = new char[len+1]; // str에 크기가 (len+1)인 char 타입 배열을 동적 할당
	for (int i=0; i<len; i++) { // str의 길이만큼 반복
		str[i] = neyong[i]; // str에 문자열 neyong의 요소를 저장
	}
}

Str::~Str() { // 소멸자
	delete[] str; // str의 메모리 해제
}

int Str::length(void) { // string의 길이를 리턴하는 함수
	return len; // len(string의 길이) 리턴
}

char* Str::contents(void) { // string의 내용을 리턴하는 함수
	return str; // string의 내용 리턴
}

int Str::compare(class Str& a) { // a의 내용과 strcmp
	int result = strcmp(str, a.str); // 기존 객체의 str과 새로운 class의 객체 a의 a.str을 strcmp 처리하고 결괏값을 저장
	// strcmp(str1, str2) : str1 == str2이면 0, str1 < str2면 음수, str1 > str2면 양수 반환 
	return result; // strcmp(str, a.str)의 결괏값을 리턴
}

int Str::compare(const char *a) { // a의 내용과 strcmp
	int result = strcmp(str, a); // 기존 객체의 str과 문자열 a를 strcmp 처리하고 결괏값을 저장
	return result; // strcmp(str, a)의 결괏값을 리턴
}

void Str::operator=(const char *a) { // string의 값을 대입, 연산자 다중정의
	len = strlen(str); // len에 str의 길이 저장
	if (len < strlen(a)) { // len < 문자열 a의 길이면
		cout << "error!" << endl; // 에러 메세지 출력
	}
	else { // len >= 문자열 a의 길이면
		strcpy(str, a); // 문자열 a의 내용을 str에 복사
		str[strlen(a)] = '\0'; // str[strlen(a)]에 NULL문자를 넣음으로써 str과 문자열 a를 완전히 동일하게 만듦
	}
}

void Str::operator=(class Str& a) { // Str의 내용을 대입, 연산자 다중정의
	len = strlen(str); // len에 str의 길이 저장
	if (len < strlen(a.str)) { // len < a.str의 길이면
		cout << "error!" << endl; // 에러 메세지 출력
	}
	else { // len >= a.str의 길이면
		strcpy(str, a.str); // a.str의 내용을 str에 복사
		str[strlen(a.str)] = '\0'; //str[strlen(a.str)]에 NULL문자를 넣음으로써 str과 문자열 a를 완전히 동일하게 만듦
	}
}
